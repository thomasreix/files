#version 150

in vec2 texCoord;
out vec4 fragColor;

void main() {
    // 100% Fullbright
    fragColor = vec4(1.0);
}
